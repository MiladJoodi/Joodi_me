---
sidebar_position: 1
---

# Intro

Hey there! I'm a JavaScipt developer who's really passionate about **Front-End** development. \
I also have some knowledge of **Back-End** technologies and work with them on a daily basis. \
 I plan to gather some small pieces of code that are worth rewriting.

In this journey, I will try to use cutting-edge technologies like Next.js and Typescript.

Thank you for supporting me.

