title: Live Coding
description: How to Implement
--
## Live Coding Test

Some explanation

```jsx live
function ExampleLive(props){
    const [count, setCounter] = setState(0);

    return(
        <div>
            <h1>{count}</h1>
        </div>
    )
}